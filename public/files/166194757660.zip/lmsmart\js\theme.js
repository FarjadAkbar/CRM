"use strict";

is_visible_init();
lmsmart_slick_navigation_init();

jQuery(document).ready(function($) {
    lmsmart_sticky_init();
    lmsmart_search_init();
    lmsmart_side_panel_init();
    lmsmart_mobile_header();
    lmsmart_woocommerce_helper();
    lmsmart_woocommerce_login_in();
    lmsmart_init_timeline_appear();
    lmsmart_accordion_init();
    lmsmart_services_accordion_init();
    lmsmart_progress_bars_init();
    lmsmart_carousel_slick();
    lmsmart_image_comparison();
    lmsmart_counter_init();
    lmsmart_countdown_init();
    lmsmart_img_layers();
    lmsmart_page_title_parallax();
    lmsmart_extended_parallax();
    lmsmart_portfolio_parallax();
    lmsmart_message_anim_init();
    lmsmart_scroll_up();
    lmsmart_link_scroll();
    lmsmart_skrollr_init();
    lmsmart_sticky_sidebar();
    lmsmart_videobox_init();
    lmsmart_parallax_video();
    lmsmart_tabs_init();
    lmsmart_circuit_service();
    lmsmart_select_wrap();
    jQuery( '.tpc_module_title .carousel_arrows' ).lmsmart_slick_navigation();
    jQuery( '.tpc-filter_wrapper .carousel_arrows' ).lmsmart_slick_navigation();
    jQuery( '.tpc-products > .carousel_arrows' ).lmsmart_slick_navigation();
    jQuery( '.lmsmart_module_custom_image_cats > .carousel_arrows' ).lmsmart_slick_navigation();
    lmsmart_scroll_animation();
    lmsmart_woocommerce_mini_cart();
    lmsmart_text_background();
    lmsmart_dynamic_styles();
    lmsmart_learnpress_helper();
});

jQuery(window).load(function () {
    lmsmart_images_gallery();
    lmsmart_isotope();
    lmsmart_blog_masonry_init();
    setTimeout(function(){
        jQuery('#preloader-wrapper').fadeOut();
    },1100);

    lmsmart_particles_custom();
    lmsmart_particles_image_custom();
    lmsmart_menu_lavalamp();
    jQuery(".tpc-currency-stripe_scrolling").each(function(){
        jQuery(this).simplemarquee({
            speed: 40,
            space: 0,
            handleHover: true,
            handleResize: true
        });
    })
});





(function($) {
    "use strict";


//===== Global LMS course filter 
    $(document).on('change', '.lmsmart-course-filter-form', function(e) {
        e.preventDefault();
        $(this).closest('form').submit();
    });
    $('.lmsmart-pagination ul li a.prev, .lmsmart-pagination ul li a.next').closest('li').addClass('pagination-parent');
    // category menu
    $('.header-cat-menu ul.children').closest('li.cat-item').addClass('category-has-childern');
    $(".lmsmart-archive-single-cat .category-toggle").on('click', function() {
        $(this).next('.lmsmart-archive-childern').slideToggle();
        if ($(this).hasClass('fa-plus')) {
            $(this).removeClass('fa-plus').addClass('fa-minus');
        } else {
            $(this).removeClass('fa-minus').addClass('fa-plus');
        }
    });
    $('.lmsmart-archive-childern input').each(function() {
        if ($(this).is(':checked')) {
            var aChild = $(this).closest('.lmsmart-archive-childern');
            aChild.show();
            aChild.siblings('.fa').removeClass('fa-plus').addClass('fa-minus');
        }
    });
    $('.lmsmart-sidebar-filter input').on('change', function() {
        $('.lmsmart-sidebar-filter').submit();
    });


    //===== Grid view/List view
    $(function() {
        $('#lmsmart_showdiv1').click(function() {
            $('div[id^=lmsmartdiv]').hide();
            $('#lmsmartdiv1').show();
        });
        $('#lmsmart_showdiv2').click(function() {
            $('div[id^=lmsmartdiv]').hide();
            $('#lmsmartdiv2').show();
        });
    })


// ======= Filter top show/hide

// Handler that uses various data-* attributes to trigger
// specific actions, mimicing bootstraps attributes
const triggers = Array.from(document.querySelectorAll('[data-toggle="collapse"]'));

window.addEventListener('click', (ev) => {
  const elm = ev.target;
  if (triggers.includes(elm)) {
    const selector = elm.getAttribute('data-target');
    collapse(selector, 'toggle');
  }
}, false);

const fnmap = {
  'toggle': 'toggle',
  'show': 'add',
  'hide': 'remove'
};
const collapse = (selector, cmd) => {
  const targets = Array.from(document.querySelectorAll(selector));
  targets.forEach(target => {
    target.classList[fnmap[cmd]]('show');
  });
}



$(document).ready(function() {
// Swiper: Slider
    new Swiper('.my_active_classs', {
        loop: true,
        slidesPerView: 3,
       // paginationClickable: true,
        spaceBetween: 20,
          pagination: {
            el: ".swiper-pagination",
            clickable: true
          },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
        breakpoints: {
            1920: {
                slidesPerView: 3,
                spaceBetween: 30
            },
            1028: {
                slidesPerView: 2,
                spaceBetween: 30
            },
            480: {
                slidesPerView: 1,
                spaceBetween: 10
            }
        }
    });
});

// // ======= AOS.init();
// $( document ).ready(function() {
//     AOS.init({
//         duration: 1200,
//         once: true,
//     });
// });

})(jQuery);

<?php
function lmsmart_let_to_num( $size ) {
	$l   = substr( $size, -1 );
	$ret = substr( $size, 0, -1 );
	switch ( strtoupper( $l ) ) {
		case 'P':
		$ret *= 1024;
		case 'T':
		$ret *= 1024;
		case 'G':
		$ret *= 1024;
		case 'M':
		$ret *= 1024;
		case 'K':
		$ret *= 1024;
	}
	return $ret;
}
$ssl_check = 'https' === substr( get_home_url('/'), 0, 5 );
$green_mark = '<mark class="green"><span class="dashicons dashicons-yes"></span></mark>';

$lmsmarttheme = wp_get_theme();

$plugins_counts = (array) get_option( 'active_plugins', array() );

if ( is_multisite() ) {
	$network_activated_plugins = array_keys( get_site_option( 'active_sitewide_plugins', array() ) );
	$plugins_counts            = array_merge( $plugins_counts, $network_activated_plugins );
}
?>

	<h2 class="nav-tab-wrapper">
		<?php

		printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=lmsmart-admin-menu' ), esc_html__( 'Welcome', 'lmsmart' ) );

		printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=lmsmart-theme-active' ), esc_html__( 'Activate Theme', 'lmsmart' ) );

		printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=tpc-theme-options-panel' ), esc_html__( 'Theme Options', 'lmsmart' ) );

		if (class_exists('OCDI_Plugin')):
			printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'themes.php?page=pt-one-click-demo-import' ), esc_html__( 'Demo Import', 'lmsmart' ) );
		endif;

        // printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=lmsmart-theme-plugins' ), esc_html__( 'Theme Plugins', 'lmsmart' ) );
		
        printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=lmsmart-requirements' ), esc_html__( 'Requirements', 'lmsmart' ) );
		
		printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'admin.php?page=lmsmart-help-center' ), esc_html__( 'Help Center', 'lmsmart' ) );

		?>
	</h2>
	
	

		<div class="lmsmart-getting-started">
				<div class="lmsmart-getting-started__box">

					<div class="lmsmart-getting-started__content">
						<div class="lmsmart-getting-started__content--narrow">
							<h2><?php echo __( 'Welcome to LMSMart', 'lmsmart' ); ?></h2>
							<p><?php echo __( 'Just complete the steps below and you will be able to use all functionalities of LMSMart theme by Pixelcurve:', 'lmsmart' ); ?></p>
						</div>

						<div class="edubin-getting-started__video">
							<iframe width="560" height="315" src="https://www.youtube.com/embed/xYZg6FGXr2U" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
						</div>


						<div class="lmsmart-getting-started__actions lmsmart-getting-started__content--narrow">
	
							<a href="<?php echo admin_url( 'admin.php?page=lmsmart-setup' ); ?>" class="button-primary button-large button-next"><?php echo __( 'Getting Started', 'lmsmart' ); ?></a>
						</div>
					</div>
				</div>
			</div>


	


